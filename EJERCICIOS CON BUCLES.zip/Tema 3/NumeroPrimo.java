import java.util.Scanner;

public class NumeroPrimo
{
	public static void main(String [] args)
	
	//Creacion de variables
	
	int num;
	String fin = "fin";
	Scanner sc = new Scanner(System.in);
	
	//Solución del problema
	
	System.out.print("Dime un numero y te dire si es primo o no.");
	num = sc.nextInt();
	
	do
	{
		
	}
	while (
	
	
	
	
	
	
	
	
