import java.util.Scanner;

public class MayusMin
{
	public static void main(String [] args)
	{
		
		//Creación de variables
		String cad;
		char a;
		Scanner sc = new Scanner(System.in);
		
		//Resolución del problema
		System.out.print("Escribe una cadena");
		a = sc.nextLine().charAt(0);
		
		switch (a)
		{
			case .isUpperCase(a):
				System.out.print("Has escrito en mayusculas");
				break;
			case a.isLowerCase():
				System.out.print("Has escrito en minuscula");
				break;
		}
	}
}