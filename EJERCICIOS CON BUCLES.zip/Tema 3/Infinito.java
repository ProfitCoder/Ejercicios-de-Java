public class Infinito
{
	public static void main(String [] args)
	{
		
		//Creación de variables
		int i;
		
		//Resolucion del problema
		for (i=0;i<=6;i++)
		{
			System.out.print("\nIteración " + i);
		}
	}
}