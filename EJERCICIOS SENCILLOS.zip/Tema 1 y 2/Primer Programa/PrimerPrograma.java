public class PrimerPrograma
{
	public static void main(String[] args)
	{
		System.out.println("Módulo Profesional - PROGRAMACIÓN");
		System.out.println("UNIDAD 1 - Introducción a la programación");
		System.out.println("Pablo Manuel Fernández Velázquez");
		System.out.println("22/09/2025");
		System.out.println("Este es mi primer programa escrito en Java");
	}
}
	