public class OperadoresAsignacion
{
	public static void main(String [] args)
	{
		int x,y;
		x = 5;			//operador de asignacion
		y = 3; 			//operador de asignacion
		
		//operadores de asignacion combinada
		System.out.printf("el valor de ex es %d y el valor de y es %d", x, y);				//Se utiliza printf para cadenas
		x += y;
	}
}