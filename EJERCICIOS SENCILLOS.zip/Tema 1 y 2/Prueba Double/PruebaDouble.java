public class PruebaDouble{
	public static void main(String [] args)
	{
		Double a,b,diferencia;
		a=24.4;
		b=23.0;
		
		//Para mostrar la diferencia
		diferencia = a - b;
		System.out.println(diferencia);
	}
}



//Sale de solucion 1.399999999986 porque el ordenador no puede guardar 1.4 y los 23 o 24.4 tampoco