public class Practica+=
{
	public static void main(String [] args)
	{
		int a=10, b=5;
		b+=a;
		System.out.printf("a=%d y b=%d",a,b);
	}
}



/*Lo que pasa aqui es que el %d sirve como cadena para coger el valor de despues
y que el += lo que hace es sumar*/

