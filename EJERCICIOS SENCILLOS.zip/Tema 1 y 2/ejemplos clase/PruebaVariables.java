public class PruebaVariables{
	public static void main(String [] args)
	{
		int var1=132,var2;
		System.out.println(var1);
		var2 = var1;
		System.out.println(var2);
	}
}