import java.util.Scanner;

public class Prueba2
{
	public static void main(String [] args)
	{
		
		//Creación de variables
		int a;
		Scanner sc = new Scanner(System.in);
		
		//Solucion 
		
		System.out.print("Dime un numero ");
		a = sc.nextInt();
		
		System.out.print("\nEl numero que has dicho es " + a);
		
	}
}