import java.util.Scanner;

public class DadoAleatorio
{
	public static void main(String [] args)
	{
		
		//Creación de variables y objetos
		int x,y;
		Scanner sc = new Scanner;
		
		//Resolución del problema
		
		
		
		
		
		
		
	}
}