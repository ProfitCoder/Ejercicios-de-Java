public class CadenasEj6
{
	public static void main(String [] args)
	{
		
		//Creación e inicialización de variables y objetos
		String cad1="",cad2="Buenos ",cad3="dias";
		
		//Resolución de problema
		cad1 = cad1.concat(cad2);
		cad1 = cad1.concat(cad3);
		
		System.out.print(cad1);
		
	}
}