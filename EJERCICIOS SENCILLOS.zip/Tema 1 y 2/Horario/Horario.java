public class Horario
{
	public static void main(String [] args)
	{
		System.out.println("  ...................................................... 		");
		System.out.printf("%3s   %4s   %4s   %4s   %4s   %4s   %3s\n"," |","lunes", "martes", "miercoles", "jueves", "viernes","| ");
		System.out.println("  ......................................................		");
		System.out.printf("%3s   %4s   %5s   %7s   %8s   %7s   %5s\n"," |","PRO", "BD", "BD", "PRO", "SI","| ");
		System.out.printf("%3s   %4s   %5s   %7s   %8s   %7s   %5s\n"," |","PRO", "BD", "BD", "PRO", "SI","| ");
		System.out.printf("%3s   %3s   %6s   %7s   %8s   %7s   %5s\n"," |","SI", "ED", "DIG", "SI", "ED","| ");
		System.out.printf("%3s   %4s   %3s   %6s   %6s   %4s   %3s\n"," |","Recreo", "Recreo", "Recreo", "  Recreo", " Recreo","| ");
		System.out.printf("%3s   %3s   %6s   %7s   %8s   %7s   %5s\n"," |","SI", "ED", "PRO", "BD", "PRO","| ");
		System.out.printf("%3s   %4s   %5s   %7s   %8s   %7s   %5s\n"," |","IP1", "LM", "BD", "BD", "PRO","| ");
		System.out.printf("%3s   %4s   %5s   %7s   %8s   %7s   %5s\n"," |","IP1", "LM", "LM", "SOS", "IP1","| ");
		System.out.println("  ......................................................		");
	}
}